#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

char *mesg = "hello maggie";

void main (){
char buf[1024];
int fd[2];
pipe(fd);


if (fork() != 0){
write(fd[1], mesg, strlen(mesg) + 1) ;
}
}
else { /*Child code */
read(fd[0], buf, 1024) ;
printf("Got this from Parent!!: %s\n", buf) ;
}
}
